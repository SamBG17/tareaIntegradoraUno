import java.util.Scanner;

public class seguimiento{
/**
 * Displays information according to the selected route. <br>
 * <b>Pre: </b> A string corresponding to one of the available routes "ladera", "oriente", or "farallones" must be entered. <br>
 * <b>Post: </b> Displays the information for the selected route, including the meeting point, start time, and end time. <br>
 * @param ruta The selected route. Must be "ladera", "oriente", or "farallones". Case is not considered.
 */

    public static void seleccionarRuta(String ruta){

        if (ruta.equalsIgnoreCase("ladera")){

            System.out.println("Excellent! The Ruta de Ladera has as its meeting point the Bulevar del Rio starting at 7:00 am, and ends at 1:30 pm.");

        } else if (ruta.equalsIgnoreCase("oriente")){

            System.out.println("Excellent! The Ruta de Oriente has as its meeting point the Bulevar del Rio starting at 7:00 am, and ends at 1:00 pm.");

        } else if (ruta.equalsIgnoreCase("farallones")) {

            System.out.println("Excellent! The Farallones Route has as meeting point Calle 16 - Universidad del Valle starting at 6:40 am, and ends at 4:00 pm.");
            
        }

    }
/**
 * Displays a message on the screen if the temperature is ideal.<br>
 * <b>Pre: </b> The temperature and humidity values have already been recorded. <br>
 * <b>Post: </b> If temperature >= 20 && temperature <= 25 && humidity >= 40 && humidity <= 60, displays the message: 
 * "It's a nice day to walk around Cali!" <br>
 * 
 * @param temperatura temperature in degrees Celsius, defined as a double. temperature != null && temperature != "".
 * @param humedad relative humidity. It should be an integer between 0 and 100. humidity != null && humidity != "".
 */
    public static void datosMeteorologicos(double temperatura, int humedad){

        if(temperatura>=20 && temperatura<=25 && humedad>=40 && humedad<=60){
            System.out.println("It's a nice day to walk around Cali!");
        }
    }
/**
 * Calculates the number of buses needed for the route.
 * <b>Pre: </b> The number of participants and guides has already been recorded as non-negative integers. <br>
 * <b>Post: </b> Computes the number of buses required, considering that dividing by 25 does not always result in an integer. <br>
 * @param participantes the number of participants attending the route. It should be a non-negative integer.
 * @param guias the number of guides attending the route. It should be a non-negative integer.
 * @return the number of buses as an integer (rounded up if necessary).
 */
    public static int busesNecesarios (int participantes, int guias){
        int numPersonas = participantes + guias;
        int resultado= (numPersonas/25);
        if (numPersonas % 25 !=0){
            resultado++;
        }
        return resultado;
    }
/**
 * Evaluates the temperature and displays a message depending on it.
 * <b>Pre: </b> The temperature value has already been recorded. <br>
 * <b>Post: </b> Returns a string with a message depending on the temperature. <br>
 * @param temperatura temperature in degrees Celsius, defined as a double. temperature != null && temperature != "".
 * @return If the temperature is below 15, returns the message: "Wear a jacket to protect you from the cold and rain".
 * If the temperature is above 28, returns the message: "Carry a thermos of water, drink to hydrate yourself".
 * If none of the above conditions are met, returns the message: "Enjoy the hike".
 */
    public static String verificarTemperatura(double temperatura){
        String resultado="";

        if (temperatura<15){
            resultado ="Wear a jacket to protect you from the cold and rain.";
        } else if (temperatura>28){
            resultado ="Carry a thermos of water, drink to hydrate yourself.";
        } else {
            resultado = "Enjoy the hike";
        }

        return resultado;

    }

/**
 * Depending on the registered volunteer's name, they may receive a free ticket.
 * <b>Pre: </b> The volunteer's name has already been stored and must not be null. <br>
 * <b>Post: </b> If the first letter of the volunteer's name is a vowel (a, e, i, o, u), the message: 
 * "Contact 1800456789 for a free ticket to a COP16 conference" is displayed. <br>
 * @param a The first letter of the volunteer's name. a != null && a != "".
 */
    public static void obtenerRegalo(String a){
        char vocal = Character.toLowerCase (a.charAt(0));
        if (vocal == 'a'||vocal == 'e' ||vocal == 'i' || vocal == 'o' ||vocal == 'u'){
            System.out.println("Contact 1800456789 for a free ticket to a COP16 conference. ");
        }
    }
    public static void main (String[] args ){
        Scanner in = new Scanner(System.in);

        System.out.println("Welcome volunteer to the COP 16 Cali - Colombia Ecological Routes Interaction application.");
        System.out.println("What's your name?: ");
        String name = in.nextLine(); // saves the name of the volunteer in a string variable called name.
        obtenerRegalo(name);
        System.out.println("Please, type your ID: ");
        String cedula = in.nextLine(); // saves the id of the volunteer in a string variable called cedula.

        System.out.println("Welcome, "+name+"!");

        System.out.println("Which route will you register today?");
        System.out.println("[1] Ladera");
        System.out.println("[2] Oriente");
        System.out.println("[3] Farallones");

        String ruta = in.nextLine(); // saves the route name in a string variable called ruta.
        seleccionarRuta(ruta); // calls the seleccionarRuta method; using the string saved in ruta.

        System.out.println("How many participants will attend the walk today? ");
        int participantes = in.nextInt(); // saves the number of participants in the int variable participantes.
        in.nextLine();
        System.out.println("How many guides will come to the walk today? ");
        int guias = in.nextInt(); // saves the number of guides in the int variable guias.
        in.nextLine();
        System.out.println("Enter the temperature in degrees Celsius °C: ");
        double temperatura = in.nextDouble(); // saves the temperature in the double variable temperatura.
        in.nextLine();
        System.out.println("Enter the relative humidity percentage: ");
        int humedad = in.nextInt(); // saves the relative humidity percentage in the int variable humedad.
        in.nextLine();
        int numPersonas = participantes + guias;
        
        String mensaje = verificarTemperatura(temperatura); // defines the variable mensaje as a string and assigns it the result of the method verificarTemperatura taking into account the value of the variable temperatura.
        System.out.println(mensaje);
        datosMeteorologicos(temperatura, humedad); // calls the datosMeteorologicos method; using the values saved in temperatura and humedad.

        int numBuses = busesNecesarios(participantes,guias); // defines the variable numBuses as a int and assigns it the result of the method busesNecesarios taking into account the values of the participantes and guias variables.

        System.out.println("With a total of "+numPersonas+" people taking part in the activity, a total of: "+numBuses+" buses will be needed to carry it out successfully. See you at COP16!");

        in.close();
    }
}